<?php

declare(strict_types=1);

namespace Book\Part1\Chapter3\ExceptionSimple;

use Exception;

final class FooException extends Exception
{
}
