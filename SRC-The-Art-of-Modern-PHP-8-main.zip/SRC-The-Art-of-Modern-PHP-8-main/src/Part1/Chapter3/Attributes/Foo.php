<?php

declare(strict_types=1);

namespace Book\Part1\Chapter3\Attributes;

#[WrittenByAttribute('Joseph')]
final class Foo
{
}
