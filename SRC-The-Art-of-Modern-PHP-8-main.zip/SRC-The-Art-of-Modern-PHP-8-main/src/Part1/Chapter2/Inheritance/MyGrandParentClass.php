<?php

declare(strict_types=1);

namespace Book\Part1\Chapter2\Inheritance;

abstract class MyGrandParentClass
{
    protected int $foo = 1;
}
