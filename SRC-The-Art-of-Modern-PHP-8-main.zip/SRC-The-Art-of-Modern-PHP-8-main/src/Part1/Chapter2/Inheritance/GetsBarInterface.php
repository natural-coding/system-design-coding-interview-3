<?php

declare(strict_types=1);

namespace Book\Part1\Chapter2\Inheritance;

interface GetsBarInterface
{
    public function getBar(): int;
}
