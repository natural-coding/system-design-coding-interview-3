<?php

declare(strict_types=1);

namespace Book\Part1\Chapter2\Inheritance;

interface GetsFooInterface
{
    public function getFoo(): int;
}
