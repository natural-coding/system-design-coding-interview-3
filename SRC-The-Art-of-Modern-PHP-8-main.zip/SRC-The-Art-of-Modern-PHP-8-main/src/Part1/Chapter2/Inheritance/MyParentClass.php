<?php

declare(strict_types=1);

namespace Book\Part1\Chapter2\Inheritance;

class MyParentClass extends MyGrandParentClass
{
    protected int $bar = 2;
}
