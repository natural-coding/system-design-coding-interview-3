<?php

declare(strict_types=1);

namespace Book\Part4\Chapter12\IntersectionType;

interface WorldInterface
{
    public function world(): string;
}