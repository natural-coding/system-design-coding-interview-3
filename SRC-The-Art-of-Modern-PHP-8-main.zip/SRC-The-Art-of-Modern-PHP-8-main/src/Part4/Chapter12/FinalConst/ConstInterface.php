<?php

declare(strict_types=1);

namespace Book\Part4\Chapter12\FinalConst;

interface ConstInterface
{
    const FOO   = 'bar';
    const THING = 'interface thing';
}