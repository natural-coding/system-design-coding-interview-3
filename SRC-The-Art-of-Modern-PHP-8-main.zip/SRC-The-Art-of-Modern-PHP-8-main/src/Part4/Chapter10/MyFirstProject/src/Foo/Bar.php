<?php

declare(strict_types=1);

namespace PhpBook\MyFirstProject\Foo;

final class Bar
{
}
