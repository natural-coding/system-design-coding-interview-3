<?php

declare(strict_types=1);

namespace Book\Part2\Chapter4;

$string = <<<'TEXT'
    this is a string
    TEXT;

echo "\n\n{$string[0]}\n\n";
