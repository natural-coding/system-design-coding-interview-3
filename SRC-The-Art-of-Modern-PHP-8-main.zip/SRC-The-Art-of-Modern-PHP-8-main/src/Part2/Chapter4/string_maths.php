<?php

declare(strict_types=1);

namespace Book\Part2\Chapter4;

echo "\n1 + 1 = " . \var_export(1 + 1, true) . "\n\n";

echo "\n1 + '1 or something like that' = " .
     \var_export(1 + '1 or something like that', true);
