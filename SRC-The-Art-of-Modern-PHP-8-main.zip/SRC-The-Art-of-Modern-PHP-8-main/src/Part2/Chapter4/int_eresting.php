<?php

declare(strict_types=1);

namespace Book\Part2\Chapter4;

echo "\n100 = 0100? " . \var_export(100 === 0100, true) . "\n";

echo "\n100 = 0144? " . \var_export(100 === 0144, true) . "\n";
