<?php

declare(strict_types=1);

namespace Book\Part2\Chapter6;

echo "\n30 == ' 30 ', " . \var_export(30 === ' 30 ', true) . "\n";
echo "\n30 === ' 30 ', " . \var_export(30 === ' 30 ', true) . "\n";
echo "\ntrue == ' 30 ', " . \var_export(true === ' 30 ', true) . "\n";
echo "\ntrue === ' 30 ', " . \var_export(true === ' 30 ', true) . "\n";
