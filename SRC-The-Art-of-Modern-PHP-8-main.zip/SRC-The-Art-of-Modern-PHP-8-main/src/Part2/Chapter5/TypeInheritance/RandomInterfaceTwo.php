<?php

declare(strict_types=1);

namespace Book\Part2\Chapter5\TypeInheritance;

interface RandomInterfaceTwo
{
}
