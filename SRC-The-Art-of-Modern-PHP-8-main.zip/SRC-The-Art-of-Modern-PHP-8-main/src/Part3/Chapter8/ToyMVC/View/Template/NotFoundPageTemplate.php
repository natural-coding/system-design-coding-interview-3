<?php

declare(strict_types=1);

namespace Book\Part3\Chapter8\ToyMVC\View\Template;

?>
<!DOCTYPE html>
<html>
<head>
    <title>Not Found</title>
</head>
<body>
<h1>Not Found</h1>
</ul>
</body>
</html>