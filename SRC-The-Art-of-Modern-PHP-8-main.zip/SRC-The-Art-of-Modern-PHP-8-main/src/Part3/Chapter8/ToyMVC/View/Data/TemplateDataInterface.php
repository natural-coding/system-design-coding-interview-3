<?php

declare(strict_types=1);

namespace Book\Part3\Chapter8\ToyMVC\View\Data;

interface TemplateDataInterface
{
}
