export useInfection=0

export psr4IgnoreList=()
psr4IgnoreList+=('#/src/Part4/Chapter10/MyFirstProject/.*#')

export pathsToIgnore=()
pathsToIgnore+=('src/Part4/Chapter12')
