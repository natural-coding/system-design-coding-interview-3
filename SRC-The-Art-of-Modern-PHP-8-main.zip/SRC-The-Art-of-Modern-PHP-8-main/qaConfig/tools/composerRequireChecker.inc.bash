#!/usr/bin/env bash

echo "
Skipping teh require checker, can't handle functions and constants defined in the same file
https://github.com/maglnet/ComposerRequireChecker/issues/179
"
