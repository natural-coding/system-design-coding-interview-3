<?php

declare(strict_types=1);

namespace Book\Part3\Chapter9\ToyDI\Service\EchoStuff;

interface EchoStuffInterface
{
    public function echoSomething(): void;
}
