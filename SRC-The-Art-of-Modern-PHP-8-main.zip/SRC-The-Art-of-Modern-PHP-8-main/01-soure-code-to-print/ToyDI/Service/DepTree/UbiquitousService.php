<?php

declare(strict_types=1);

namespace Book\Part3\Chapter9\ToyDI\Service\DepTree;

final class UbiquitousService
{
    public function __construct()
    {
    }
}
