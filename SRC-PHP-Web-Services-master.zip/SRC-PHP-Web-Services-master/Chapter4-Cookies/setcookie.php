<?php

setcookie("visited", true);

var_dump($_COOKIE);
