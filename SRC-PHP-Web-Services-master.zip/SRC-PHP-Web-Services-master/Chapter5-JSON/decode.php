<?php

$data = json_decode('{"message":"hello you"}', true);

var_dump($data);
