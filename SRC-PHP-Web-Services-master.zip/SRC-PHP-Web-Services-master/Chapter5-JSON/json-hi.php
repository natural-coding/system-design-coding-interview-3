<?php

$msg = array("message" => array("en" => "hello friend", "es" => "hola amigo"));

echo json_encode($msg);
